#!/usr/bin/env python3
"""
dashboard_server.py
===================
Replaces api_server.py.

- Serves the live SliceShield telemetry dashboard at http://localhost:5002/
- REST API (backward-compatible with old api_server.py):
    GET  /api/logs
    GET  /api/rca/<slice_id>
    POST /api/attack
- WebSocket (SocketIO) pushes real-time events to every connected browser:
    'new_event'   — a new audit log entry arrived
    'stats_update' — periodic throughput / alert counters
- Tails logs/response_audit.jsonl in a background thread and broadcasts
  each new line via SocketIO so the dashboard is truly live.
"""

import os
import sys
import time
import json
import threading
from datetime import datetime

try:
    from flask import Flask, jsonify, request, render_template_string
    from flask_socketio import SocketIO, emit
except ImportError as e:
    print(f"[dashboard_server] ERROR: {e}")
    print("  Run: pip install flask flask-socketio flask-cors")
    sys.exit(1)

# ── App setup ──────────────────────────────────────────────────────────────────
app = Flask(__name__)
app.config["SECRET_KEY"] = "sliceshield-secret"
socketio = SocketIO(app, cors_allowed_origins="*", async_mode="threading")

DASHBOARD_PORT = 5002
LOG_PATH  = "logs/response_audit.jsonl"
_stats    = {"events": 0, "isolations": 0, "readmissions": 0, "start_time": time.time()}

# ── Log tailer — broadcasts every new line via SocketIO ───────────────────────

def tail_log():
    os.makedirs("logs", exist_ok=True)
    if not os.path.exists(LOG_PATH):
        open(LOG_PATH, "a").close()

    with open(LOG_PATH, "r") as f:
        f.seek(0, 2)   # jump to end — only new events
        while True:
            line = f.readline()
            if not line:
                time.sleep(0.3)
                continue
            line = line.strip()
            if not line:
                continue
            try:
                event = json.loads(line)
                _stats["events"] += 1
                if event.get("event") == "slice_isolated":
                    _stats["isolations"] += 1
                elif event.get("event") == "slice_readmitted":
                    _stats["readmissions"] += 1
                socketio.emit("new_event", event)
            except json.JSONDecodeError:
                pass


def stats_broadcaster():
    while True:
        time.sleep(3)
        uptime = int(time.time() - _stats["start_time"])
        socketio.emit("stats_update", {
            "events":       _stats["events"],
            "isolations":   _stats["isolations"],
            "readmissions": _stats["readmissions"],
            "uptime_s":     uptime,
        })


# ── REST API ───────────────────────────────────────────────────────────────────

@app.route("/api/logs")
def get_logs():
    logs = []
    if not os.path.exists(LOG_PATH):
        return jsonify(logs)
    with open(LOG_PATH) as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    logs.append(json.loads(line))
                except json.JSONDecodeError:
                    pass
    return jsonify(logs)


@app.route("/api/rca/<int:slice_id>")
def get_rca(slice_id):
    try:
        reports = [
            f for f in os.listdir(".")
            if f.startswith(f"RCA_Report_Slice{slice_id}") and f.endswith(".md")
        ]
    except OSError:
        reports = []
    if not reports:
        return jsonify({"report": "No RCA report available yet."})
    with open(sorted(reports)[-1]) as f:
        return jsonify({"report": f.read()})


@app.route("/api/stats")
def get_stats():
    return jsonify({
        **_stats,
        "uptime_s": int(time.time() - _stats["start_time"]),
    })


@app.route("/api/attack", methods=["POST"])
def trigger_attack():
    data = request.get_json(force=True, silent=True) or {}
    slice_id    = int(data.get("slice", 1))
    attack_type = str(data.get("attack", "nosql"))
    allowed     = {"ddos", "nosql", "lateral", "syn_flood", "port_scan"}
    if attack_type not in allowed:
        return jsonify({"status": "error", "message": f"Unknown attack: {attack_type}"}), 400

    import subprocess
    subprocess.Popen([sys.executable, "attack_simulation.py",
                      "--slice", str(slice_id), "--attack", attack_type])
    return jsonify({"status": "success"})


# ── Dashboard HTML (served at /) ───────────────────────────────────────────────

DASHBOARD_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SliceShield — Live Telemetry</title>
<link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Barlow:wght@300;500;700&display=swap" rel="stylesheet">
<script src="https://cdn.socket.io/4.7.5/socket.io.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
<style>
  :root {
    --bg:       #030712;
    --surface:  #0d1117;
    --border:   #1e2d3d;
    --accent:   #00ffe7;
    --danger:   #ff3b5c;
    --warn:     #ffaa00;
    --ok:       #00ff88;
    --muted:    #4a6078;
    --text:     #c9d8e8;
    --font-mono: 'Share Tech Mono', monospace;
    --font-ui:   'Barlow', sans-serif;
  }

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    background: var(--bg);
    color: var(--text);
    font-family: var(--font-ui);
    min-height: 100vh;
    overflow-x: hidden;
  }

  /* Scanline overlay */
  body::before {
    content: '';
    position: fixed; inset: 0;
    background: repeating-linear-gradient(
      0deg,
      transparent,
      transparent 2px,
      rgba(0,255,231,0.015) 2px,
      rgba(0,255,231,0.015) 4px
    );
    pointer-events: none;
    z-index: 9999;
  }

  /* Grid noise */
  body::after {
    content: '';
    position: fixed; inset: 0;
    background-image:
      linear-gradient(rgba(0,255,231,0.03) 1px, transparent 1px),
      linear-gradient(90deg, rgba(0,255,231,0.03) 1px, transparent 1px);
    background-size: 40px 40px;
    pointer-events: none;
    z-index: 0;
  }

  header {
    position: relative; z-index: 10;
    display: flex; align-items: center; justify-content: space-between;
    padding: 18px 32px;
    border-bottom: 1px solid var(--border);
    background: linear-gradient(180deg, rgba(0,255,231,0.04) 0%, transparent 100%);
  }

  .logo {
    display: flex; align-items: center; gap: 14px;
  }

  .logo-icon {
    width: 36px; height: 36px;
    border: 2px solid var(--accent);
    border-radius: 6px;
    display: flex; align-items: center; justify-content: center;
    position: relative;
    animation: pulse-border 3s ease-in-out infinite;
  }

  @keyframes pulse-border {
    0%,100% { box-shadow: 0 0 8px rgba(0,255,231,0.4); }
    50%      { box-shadow: 0 0 20px rgba(0,255,231,0.8), 0 0 40px rgba(0,255,231,0.3); }
  }

  .logo-icon svg { width: 20px; height: 20px; fill: var(--accent); }

  .logo-text h1 {
    font-size: 1.1rem;
    font-weight: 700;
    letter-spacing: 0.15em;
    color: var(--accent);
    text-transform: uppercase;
  }
  .logo-text p {
    font-size: 0.68rem;
    color: var(--muted);
    letter-spacing: 0.1em;
    font-family: var(--font-mono);
  }

  .header-right {
    display: flex; align-items: center; gap: 24px;
  }

  .status-pill {
    display: flex; align-items: center; gap: 8px;
    font-family: var(--font-mono);
    font-size: 0.72rem;
    letter-spacing: 0.08em;
    color: var(--ok);
  }

  .status-dot {
    width: 8px; height: 8px;
    border-radius: 50%;
    background: var(--ok);
    animation: blink 1.4s ease-in-out infinite;
  }

  @keyframes blink {
    0%,100% { opacity: 1; } 50% { opacity: 0.2; }
  }

  #clock {
    font-family: var(--font-mono);
    font-size: 0.78rem;
    color: var(--muted);
  }

  /* Main layout */
  main {
    position: relative; z-index: 1;
    padding: 24px 32px;
    display: grid;
    grid-template-rows: auto auto 1fr auto;
    gap: 20px;
    max-width: 1600px;
    margin: 0 auto;
  }

  /* Metric strip */
  .metrics {
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    gap: 14px;
  }

  .metric {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 16px 20px;
    position: relative;
    overflow: hidden;
    transition: border-color 0.3s;
  }

  .metric::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 2px;
    background: var(--accent-color, var(--accent));
    opacity: 0.6;
  }

  .metric-label {
    font-size: 0.65rem;
    letter-spacing: 0.12em;
    color: var(--muted);
    text-transform: uppercase;
    margin-bottom: 8px;
    font-family: var(--font-mono);
  }

  .metric-value {
    font-family: var(--font-mono);
    font-size: 2rem;
    font-weight: 400;
    color: var(--accent-color, var(--accent));
    line-height: 1;
    transition: color 0.3s;
  }

  .metric-sub {
    font-size: 0.65rem;
    color: var(--muted);
    margin-top: 6px;
    font-family: var(--font-mono);
  }

  /* Attack buttons */
  .attack-panel {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 16px 20px;
    display: flex;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;
  }

  .attack-label {
    font-size: 0.65rem;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    color: var(--muted);
    font-family: var(--font-mono);
    white-space: nowrap;
  }

  .btn {
    padding: 8px 18px;
    border-radius: 6px;
    border: 1px solid;
    font-family: var(--font-mono);
    font-size: 0.72rem;
    letter-spacing: 0.08em;
    cursor: pointer;
    background: transparent;
    transition: all 0.15s;
    text-transform: uppercase;
  }

  .btn:hover { filter: brightness(1.3); transform: translateY(-1px); }
  .btn:active { transform: translateY(0); }

  .btn-ddos   { color: var(--danger); border-color: var(--danger); }
  .btn-nosql  { color: var(--warn);   border-color: var(--warn); }
  .btn-lateral { color: #bf9fff;      border-color: #bf9fff; }

  .btn-ddos:hover   { background: rgba(255,59,92,0.12); }
  .btn-nosql:hover  { background: rgba(255,170,0,0.12); }
  .btn-lateral:hover { background: rgba(191,159,255,0.12); }

  /* Middle row: slices + chart */
  .mid-row {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr 1.8fr;
    gap: 14px;
  }

  /* Slice cards */
  .slice-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 20px;
    cursor: pointer;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
  }

  .slice-card::after {
    content: '';
    position: absolute;
    inset: 0;
    background: radial-gradient(ellipse at 50% 0%, rgba(0,255,231,0.06) 0%, transparent 70%);
    opacity: 0;
    transition: opacity 0.3s;
  }

  .slice-card:hover::after { opacity: 1; }

  .slice-card.isolated {
    border-color: var(--danger) !important;
    box-shadow: 0 0 0 1px var(--danger),
                0 0 24px rgba(255,59,92,0.25),
                inset 0 0 24px rgba(255,59,92,0.05);
    animation: danger-pulse 1.5s ease-in-out infinite;
  }

  @keyframes danger-pulse {
    0%,100% { box-shadow: 0 0 0 1px var(--danger), 0 0 24px rgba(255,59,92,0.25); }
    50%      { box-shadow: 0 0 0 1px var(--danger), 0 0 40px rgba(255,59,92,0.5); }
  }

  .slice-card.recovering {
    border-color: var(--warn) !important;
    box-shadow: 0 0 20px rgba(255,170,0,0.2);
  }

  .slice-header {
    display: flex; align-items: center; justify-content: space-between;
    margin-bottom: 14px;
  }

  .slice-name {
    font-size: 0.65rem;
    letter-spacing: 0.15em;
    text-transform: uppercase;
    color: var(--muted);
    font-family: var(--font-mono);
  }

  .slice-badge {
    font-size: 0.6rem;
    padding: 3px 8px;
    border-radius: 4px;
    font-family: var(--font-mono);
    letter-spacing: 0.06em;
    text-transform: uppercase;
    font-weight: 500;
  }

  .badge-ok       { background: rgba(0,255,136,0.12); color: var(--ok); border: 1px solid rgba(0,255,136,0.3); }
  .badge-isolated { background: rgba(255,59,92,0.15); color: var(--danger); border: 1px solid rgba(255,59,92,0.4); }
  .badge-recover  { background: rgba(255,170,0,0.12); color: var(--warn); border: 1px solid rgba(255,170,0,0.3); }

  .slice-num {
    font-family: var(--font-mono);
    font-size: 2.4rem;
    color: var(--accent);
    line-height: 1;
    margin: 4px 0 10px;
  }

  .slice-card.isolated .slice-num { color: var(--danger); }

  .slice-sub {
    font-size: 0.65rem;
    color: var(--muted);
    font-family: var(--font-mono);
    line-height: 1.6;
  }

  /* Probability bar */
  .prob-bar-wrap {
    margin-top: 12px;
    height: 4px;
    background: var(--border);
    border-radius: 2px;
    overflow: hidden;
  }

  .prob-bar {
    height: 100%;
    width: 0%;
    background: var(--ok);
    border-radius: 2px;
    transition: width 0.5s ease, background 0.5s ease;
  }

  /* Event chart */
  .chart-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 16px 20px;
    display: flex;
    flex-direction: column;
  }

  .card-title {
    font-size: 0.65rem;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    color: var(--muted);
    font-family: var(--font-mono);
    margin-bottom: 12px;
  }

  .chart-card canvas { flex: 1; }

  /* Log panel */
  .log-panel {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 16px 20px;
    display: flex;
    flex-direction: column;
    min-height: 240px;
    max-height: 340px;
  }

  .log-scroll {
    flex: 1;
    overflow-y: auto;
    scrollbar-width: thin;
    scrollbar-color: var(--border) transparent;
  }

  .log-scroll::-webkit-scrollbar { width: 4px; }
  .log-scroll::-webkit-scrollbar-thumb { background: var(--border); border-radius: 2px; }

  .log-entry {
    display: flex;
    gap: 12px;
    padding: 6px 0;
    border-bottom: 1px solid rgba(30,45,61,0.5);
    font-family: var(--font-mono);
    font-size: 0.7rem;
    line-height: 1.5;
    animation: slide-in 0.3s ease;
  }

  @keyframes slide-in {
    from { opacity: 0; transform: translateX(-8px); }
    to   { opacity: 1; transform: translateX(0); }
  }

  .log-time { color: var(--muted); white-space: nowrap; flex-shrink: 0; }
  .log-badge { flex-shrink: 0; }
  .log-msg { color: var(--text); }

  .tag-isolated  { color: var(--danger); }
  .tag-readmit   { color: var(--ok); }
  .tag-default   { color: var(--accent); }

  /* RCA modal */
  .modal-overlay {
    display: none;
    position: fixed; inset: 0;
    background: rgba(3,7,18,0.85);
    backdrop-filter: blur(4px);
    z-index: 1000;
    align-items: center;
    justify-content: center;
  }

  .modal-overlay.open { display: flex; }

  .modal {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 12px;
    width: min(760px, 90vw);
    max-height: 80vh;
    display: flex;
    flex-direction: column;
    box-shadow: 0 0 60px rgba(0,0,0,0.6);
  }

  .modal-header {
    display: flex; align-items: center; justify-content: space-between;
    padding: 16px 20px;
    border-bottom: 1px solid var(--border);
  }

  .modal-title {
    font-family: var(--font-mono);
    font-size: 0.8rem;
    letter-spacing: 0.1em;
    color: var(--accent);
  }

  .modal-close {
    background: none; border: none; color: var(--muted);
    cursor: pointer; font-size: 1.2rem; line-height: 1;
    transition: color 0.2s;
  }
  .modal-close:hover { color: var(--danger); }

  .modal-body {
    padding: 20px;
    overflow-y: auto;
    flex: 1;
  }

  .modal-body pre {
    font-family: var(--font-mono);
    font-size: 0.72rem;
    white-space: pre-wrap;
    line-height: 1.7;
    color: var(--text);
  }

  /* Toast notification */
  #toast-container {
    position: fixed;
    bottom: 24px; right: 24px;
    z-index: 2000;
    display: flex;
    flex-direction: column;
    gap: 10px;
    pointer-events: none;
  }

  .toast {
    background: var(--surface);
    border: 1px solid var(--border);
    border-left: 3px solid var(--accent);
    border-radius: 8px;
    padding: 12px 16px;
    font-family: var(--font-mono);
    font-size: 0.72rem;
    color: var(--text);
    max-width: 320px;
    animation: toast-in 0.3s ease, toast-out 0.3s ease 3.7s forwards;
    pointer-events: auto;
  }

  .toast.danger { border-left-color: var(--danger); }
  .toast.ok     { border-left-color: var(--ok); }

  @keyframes toast-in {
    from { opacity: 0; transform: translateX(20px); }
    to   { opacity: 1; transform: translateX(0); }
  }
  @keyframes toast-out {
    to { opacity: 0; transform: translateX(20px); }
  }

  /* Connection indicator */
  #conn-status {
    font-family: var(--font-mono);
    font-size: 0.68rem;
    display: flex; align-items: center; gap: 6px;
  }
  .conn-dot {
    width: 7px; height: 7px; border-radius: 50%;
    background: var(--muted);
    transition: background 0.3s;
  }
  .conn-dot.connected    { background: var(--ok); }
  .conn-dot.disconnected { background: var(--danger); }
</style>
</head>
<body>

<!-- Header -->
<header>
  <div class="logo">
    <div class="logo-icon">
      <svg viewBox="0 0 24 24"><path d="M12 2L2 7v10l10 5 10-5V7L12 2zm0 2.18L20 8.5v7l-8 4-8-4v-7l8-4.32z"/></svg>
    </div>
    <div class="logo-text">
      <h1>SliceShield</h1>
      <p>5G Network Slice Security &mdash; Live Telemetry</p>
    </div>
  </div>
  <div class="header-right">
    <div id="conn-status">
      <div class="conn-dot" id="conn-dot"></div>
      <span id="conn-text">Connecting...</span>
    </div>
    <div class="status-pill">
      <div class="status-dot"></div>
      <span>SYSTEM ACTIVE</span>
    </div>
    <div id="clock"></div>
  </div>
</header>

<main>

  <!-- Metrics -->
  <div class="metrics">
    <div class="metric" style="--accent-color: var(--danger)">
      <div class="metric-label">Attacks Detected</div>
      <div class="metric-value" id="m-attacks">0</div>
      <div class="metric-sub">total events</div>
    </div>
    <div class="metric" style="--accent-color: var(--warn)">
      <div class="metric-label">Isolations</div>
      <div class="metric-value" id="m-isolations">0</div>
      <div class="metric-sub">slices isolated</div>
    </div>
    <div class="metric" style="--accent-color: var(--ok)">
      <div class="metric-label">Readmissions</div>
      <div class="metric-value" id="m-readmissions">0</div>
      <div class="metric-sub">slices restored</div>
    </div>
    <div class="metric" style="--accent-color: var(--accent)">
      <div class="metric-label">Avg Detect Time</div>
      <div class="metric-value" id="m-latency">—</div>
      <div class="metric-sub">milliseconds</div>
    </div>
    <div class="metric">
      <div class="metric-label">Uptime</div>
      <div class="metric-value" id="m-uptime">0s</div>
      <div class="metric-sub">since launch</div>
    </div>
  </div>

  <!-- Attack buttons -->
  <div class="attack-panel">
    <span class="attack-label">Inject Attack →</span>
    <button class="btn btn-ddos"    onclick="attack(0,'ddos')">DDoS &rarr; eMBB</button>
    <button class="btn btn-nosql"   onclick="attack(1,'nosql')">NoSQL &rarr; URLLC</button>
    <button class="btn btn-lateral" onclick="attack(2,'lateral')">Lateral &rarr; mMTC</button>
    <button class="btn btn-nosql"   onclick="attack(0,'syn_flood')">SYN Flood &rarr; eMBB</button>
    <button class="btn btn-lateral" onclick="attack(2,'port_scan')">Port Scan &rarr; mMTC</button>
  </div>

  <!-- Slice cards + chart -->
  <div class="mid-row">
    <!-- Slice 0: eMBB -->
    <div class="slice-card" id="card-0" onclick="showRCA(0)">
      <div class="slice-header">
        <span class="slice-name">Slice 0 &mdash; eMBB</span>
        <span class="slice-badge badge-ok" id="badge-0">NORMAL</span>
      </div>
      <div class="slice-num" id="prob-0">0.00</div>
      <div class="slice-sub">
        Attack prob<br>
        <span id="atk-type-0">—</span>
      </div>
      <div class="prob-bar-wrap">
        <div class="prob-bar" id="bar-0"></div>
      </div>
    </div>

    <!-- Slice 1: URLLC -->
    <div class="slice-card" id="card-1" onclick="showRCA(1)">
      <div class="slice-header">
        <span class="slice-name">Slice 1 &mdash; URLLC</span>
        <span class="slice-badge badge-ok" id="badge-1">NORMAL</span>
      </div>
      <div class="slice-num" id="prob-1">0.00</div>
      <div class="slice-sub">
        Attack prob<br>
        <span id="atk-type-1">—</span>
      </div>
      <div class="prob-bar-wrap">
        <div class="prob-bar" id="bar-1"></div>
      </div>
    </div>

    <!-- Slice 2: mMTC -->
    <div class="slice-card" id="card-2" onclick="showRCA(2)">
      <div class="slice-header">
        <span class="slice-name">Slice 2 &mdash; mMTC</span>
        <span class="slice-badge badge-ok" id="badge-2">NORMAL</span>
      </div>
      <div class="slice-num" id="prob-2">0.00</div>
      <div class="slice-sub">
        Attack prob<br>
        <span id="atk-type-2">—</span>
      </div>
      <div class="prob-bar-wrap">
        <div class="prob-bar" id="bar-2"></div>
      </div>
    </div>

    <!-- Timeline chart -->
    <div class="chart-card">
      <div class="card-title">Event Timeline — Last 40 Events</div>
      <canvas id="timelineChart"></canvas>
    </div>
  </div>

  <!-- Live audit log -->
  <div class="log-panel">
    <div class="card-title">Live Audit Stream</div>
    <div class="log-scroll" id="log-scroll"></div>
  </div>

</main>

<!-- RCA Modal -->
<div class="modal-overlay" id="rca-modal">
  <div class="modal">
    <div class="modal-header">
      <span class="modal-title" id="rca-title">Root Cause Analysis</span>
      <button class="modal-close" onclick="closeModal()">&#x2715;</button>
    </div>
    <div class="modal-body">
      <pre id="rca-content">Loading...</pre>
    </div>
  </div>
</div>

<!-- Toast container -->
<div id="toast-container"></div>

<script>
// ── Socket.IO ──────────────────────────────────────────────────────────────────
const socket = io();
const connDot  = document.getElementById('conn-dot');
const connText = document.getElementById('conn-text');

socket.on('connect', () => {
  connDot.className  = 'conn-dot connected';
  connText.textContent = 'Live';
  toast('WebSocket connected — live telemetry active', 'ok');
});

socket.on('disconnect', () => {
  connDot.className  = 'conn-dot disconnected';
  connText.textContent = 'Disconnected';
  toast('Connection lost — retrying...', 'danger');
});

socket.on('new_event',    handleEvent);
socket.on('stats_update', handleStats);

// ── State ──────────────────────────────────────────────────────────────────────
let totalAttacks = 0, totalIsolations = 0, totalReadmissions = 0;
let latencies    = [];
const sliceState = { 0: 'normal', 1: 'normal', 2: 'normal' };

// Chart — rolling 40-point isolation timeline
const timelineLabels = [];
const isolData       = [];
const readmitData    = [];

const ctx = document.getElementById('timelineChart').getContext('2d');
const timelineChart = new Chart(ctx, {
  type: 'line',
  data: {
    labels: timelineLabels,
    datasets: [
      {
        label: 'Isolations',
        data: isolData,
        borderColor: '#ff3b5c',
        backgroundColor: 'rgba(255,59,92,0.08)',
        fill: true,
        tension: 0.4,
        pointRadius: 3,
        pointBackgroundColor: '#ff3b5c',
      },
      {
        label: 'Readmissions',
        data: readmitData,
        borderColor: '#00ff88',
        backgroundColor: 'rgba(0,255,136,0.06)',
        fill: true,
        tension: 0.4,
        pointRadius: 3,
        pointBackgroundColor: '#00ff88',
      }
    ]
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    animation: { duration: 400 },
    plugins: {
      legend: {
        labels: {
          color: '#4a6078',
          font: { family: "'Share Tech Mono'", size: 10 }
        }
      }
    },
    scales: {
      x: {
        ticks: { color: '#4a6078', font: { family: "'Share Tech Mono'", size: 9 }, maxTicksLimit: 8 },
        grid:  { color: 'rgba(30,45,61,0.6)' }
      },
      y: {
        ticks: { color: '#4a6078', font: { family: "'Share Tech Mono'", size: 9 }, stepSize: 1 },
        grid:  { color: 'rgba(30,45,61,0.6)' },
        min: 0
      }
    }
  }
});

function pushChart(isIsolation) {
  const t = new Date().toLocaleTimeString('en', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  timelineLabels.push(t);
  isolData.push(isIsolation ? 1 : 0);
  readmitData.push(isIsolation ? 0 : 1);
  if (timelineLabels.length > 40) {
    timelineLabels.shift(); isolData.shift(); readmitData.shift();
  }
  timelineChart.update();
}

// ── Event handlers ─────────────────────────────────────────────────────────────
function handleEvent(e) {
  addLogEntry(e);

  if (e.event === 'slice_isolated') {
    totalAttacks++;
    totalIsolations++;
    document.getElementById('m-attacks').textContent    = totalAttacks;
    document.getElementById('m-isolations').textContent = totalIsolations;

    const sid = e.slice_id;
    sliceState[sid] = 'isolated';
    setSliceIsolated(sid, e.attack_type || '—', e.avg_prob || 0.96);
    pushChart(true);

    if (e.total_ms) {
      latencies.push(e.total_ms);
      document.getElementById('m-latency').textContent =
        (latencies.reduce((a,b)=>a+b,0)/latencies.length).toFixed(1) + 'ms';
    }

    toast(`Slice ${sid} ISOLATED — ${e.attack_type || 'attack'}`, 'danger');

  } else if (e.event === 'slice_readmitted') {
    totalReadmissions++;
    document.getElementById('m-readmissions').textContent = totalReadmissions;

    const sid = e.slice_id;
    sliceState[sid] = 'normal';
    setSliceNormal(sid);
    pushChart(false);

    toast(`Slice ${sid} RESTORED`, 'ok');
  }
}

function handleStats(s) {
  // Stats from the server-side counter (redundant but keeps counts in sync)
  document.getElementById('m-uptime').textContent = formatUptime(s.uptime_s);
}

// ── Slice card updates ─────────────────────────────────────────────────────────
function setSliceIsolated(sid, attackType, prob) {
  const card  = document.getElementById(`card-${sid}`);
  const badge = document.getElementById(`badge-${sid}`);
  const bar   = document.getElementById(`bar-${sid}`);
  const probEl = document.getElementById(`prob-${sid}`);
  const typeEl = document.getElementById(`atk-type-${sid}`);

  card.classList.add('isolated');
  card.classList.remove('recovering');
  badge.className  = 'slice-badge badge-isolated';
  badge.textContent = 'ISOLATED';
  probEl.textContent = typeof prob === 'number' ? prob.toFixed(2) : prob;
  typeEl.textContent = attackType;
  bar.style.width      = (prob * 100) + '%';
  bar.style.background = '#ff3b5c';
}

function setSliceNormal(sid) {
  const card  = document.getElementById(`card-${sid}`);
  const badge = document.getElementById(`badge-${sid}`);
  const bar   = document.getElementById(`bar-${sid}`);
  const probEl = document.getElementById(`prob-${sid}`);
  const typeEl = document.getElementById(`atk-type-${sid}`);

  card.classList.remove('isolated', 'recovering');
  badge.className  = 'slice-badge badge-ok';
  badge.textContent = 'NORMAL';
  probEl.textContent = '0.00';
  typeEl.textContent = '—';
  bar.style.width      = '0%';
  bar.style.background = '#00ff88';
}

// ── Log entries ────────────────────────────────────────────────────────────────
function addLogEntry(e) {
  const scroll = document.getElementById('log-scroll');
  const div    = document.createElement('div');
  div.className = 'log-entry';

  const ts  = e.timestamp
    ? new Date(e.timestamp).toLocaleTimeString()
    : new Date().toLocaleTimeString();

  let tagClass = 'tag-default';
  let tag      = e.event || 'event';
  if (e.event === 'slice_isolated')  { tagClass = 'tag-isolated'; tag = 'ISOLATED'; }
  if (e.event === 'slice_readmitted'){ tagClass = 'tag-readmit';  tag = 'READMIT'; }

  const detail = e.attack_type
    ? `slice=${e.slice_id} type=${e.attack_type} prob=${(e.avg_prob||0).toFixed(2)}`
    : `slice=${e.slice_id}`;

  div.innerHTML = `
    <span class="log-time">${ts}</span>
    <span class="log-badge ${tagClass}">[${tag}]</span>
    <span class="log-msg">${detail}</span>
  `;

  scroll.appendChild(div);
  scroll.scrollTop = scroll.scrollHeight;

  // Keep at most 200 entries in DOM
  while (scroll.children.length > 200) {
    scroll.removeChild(scroll.firstChild);
  }
}

// ── Attack injection ───────────────────────────────────────────────────────────
function attack(sliceId, type) {
  fetch('/api/attack', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ slice: sliceId, attack: type })
  }).then(r => r.json()).then(d => {
    if (d.status !== 'success') toast('Attack injection failed: ' + d.message, 'danger');
  }).catch(() => toast('Could not reach API server', 'danger'));
}

// ── RCA modal ──────────────────────────────────────────────────────────────────
function showRCA(sid) {
  document.getElementById('rca-modal').classList.add('open');
  document.getElementById('rca-title').textContent = `RCA — Slice ${sid}`;
  document.getElementById('rca-content').textContent = 'Loading...';

  fetch(`/api/rca/${sid}`)
    .then(r => r.json())
    .then(d => {
      document.getElementById('rca-content').textContent = d.report || 'No report yet.';
    })
    .catch(() => {
      document.getElementById('rca-content').textContent = 'Failed to load RCA report.';
    });
}

function closeModal() {
  document.getElementById('rca-modal').classList.remove('open');
}

document.getElementById('rca-modal').addEventListener('click', e => {
  if (e.target === e.currentTarget) closeModal();
});

// ── Toasts ─────────────────────────────────────────────────────────────────────
function toast(msg, type = '') {
  const c = document.getElementById('toast-container');
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.textContent = msg;
  c.appendChild(t);
  setTimeout(() => t.remove(), 4200);
}

// ── Clock + uptime ──────────────────────────────────────────────────────────────
function formatUptime(s) {
  if (s < 60)   return `${s}s`;
  if (s < 3600) return `${Math.floor(s/60)}m ${s%60}s`;
  return `${Math.floor(s/3600)}h ${Math.floor((s%3600)/60)}m`;
}

setInterval(() => {
  document.getElementById('clock').textContent =
    new Date().toLocaleTimeString('en-GB');
}, 1000);

// ── Load existing logs on page load ───────────────────────────────────────────
fetch('/api/logs')
  .then(r => r.json())
  .then(logs => {
    logs.slice(-50).forEach(handleEvent);   // last 50 entries
  })
  .catch(() => {});
</script>
</body>
</html>"""


@app.route("/")
def dashboard():
    return render_template_string(DASHBOARD_HTML)


# ── SocketIO events ────────────────────────────────────────────────────────────

@socketio.on("connect")
def on_connect():
    pass   # tailer thread handles broadcasting


# ── Bootstrap ─────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    os.makedirs("logs", exist_ok=True)

    # Start background threads
    threading.Thread(target=tail_log,         daemon=True, name="log-tailer").start()
    threading.Thread(target=stats_broadcaster, daemon=True, name="stats-bc").start()

    print(f"[SliceShield] Dashboard → http://localhost:{DASHBOARD_PORT}/")
    print(f"[SliceShield] API       → http://localhost:{DASHBOARD_PORT}/api/logs")

    socketio.run(app, host="0.0.0.0", port=DASHBOARD_PORT,
                 debug=False, use_reloader=False, log_output=False, allow_unsafe_werkzeug=True)
