#!/usr/bin/env python3
"""
launcher.py
===========
Single-command orchestrator for the full SliceShield stack.

Usage:
    python launcher.py                      # start everything (skip-train mode)
    python launcher.py --mode kafka         # use live Kafka instead of demo
    python launcher.py --train              # run FL training first, then start
    python launcher.py --no-rca            # skip RCA agent (needs GROQ_API_KEY)
    python launcher.py --no-sniffer        # skip packet sniffer
    python launcher.py --stop              # kill all managed processes

What it starts (in order):
    1. dashboard_server.py   — Flask + SocketIO API + live telemetry dashboard (port 5002)
    2. run_pipeline.py       — Detection + Response engine
    3. rca_agent.py          — Forensics / LLM analysis (optional)
    4. packet_sniffer.py     — Live packet capture (optional, Kafka mode only)

All stdout/stderr is prefixed and colour-coded in this terminal.
A PID file (.sliceshield.pids) is written so --stop can clean up.
"""

import os
import sys
import time
import signal
import shutil
import argparse
import threading
import subprocess
import webbrowser
from datetime import datetime

# ── ANSI colour codes ──────────────────────────────────────────────────────────
RESET  = "\033[0m"
BOLD   = "\033[1m"
COLOURS = {
    "DASHBOARD" : "\033[38;5;51m",   # cyan
    "PIPELINE"  : "\033[38;5;82m",   # green
    "RCA"       : "\033[38;5;214m",  # orange
    "SNIFFER"   : "\033[38;5;171m",  # purple
    "LAUNCHER"  : "\033[38;5;196m",  # red
}

PID_FILE = ".sliceshield.pids"
DASHBOARD_PORT = 5002
DASHBOARD_URL  = f"http://localhost:{DASHBOARD_PORT}"

# ── Process table ──────────────────────────────────────────────────────────────
# Each entry: (label, command_builder_fn)
# command_builder_fn receives parsed args and returns a list of strings.

def _python():
    """Always use the same interpreter that launched the launcher."""
    return sys.executable


def build_commands(args):
    cmds = []

    # 1. Dashboard server — always first so API is ready before pipeline connects
    cmds.append(("DASHBOARD", [_python(), "dashboard_server.py"]))

    # 2. Detection + Response pipeline
    pipeline_cmd = [_python(), "run_pipeline.py", "--skip-data"]
    if not args.train:
        pipeline_cmd.append("--skip-train")
    pipeline_cmd += ["--mode", args.mode]
    cmds.append(("PIPELINE", pipeline_cmd))

    # 3. RCA forensics agent (optional — needs GROQ_API_KEY)
    if not args.no_rca:
        cmds.append(("RCA", [_python(), "rca_agent.py"]))

    # 4. Packet sniffer (optional — only useful in kafka mode or with real interface)
    if not args.no_sniffer and args.mode == "kafka":
        sniffer_cmd = [_python(), "packet_sniffer.py",
                       "--interface", args.interface,
                       "--broker",    args.broker]
        if args.dry_run_sniffer:
            sniffer_cmd.append("--dry-run")
        cmds.append(("SNIFFER", sniffer_cmd))

    return cmds


# ── Log streaming ──────────────────────────────────────────────────────────────

def stream_output(proc, label):
    """Read stdout+stderr from a subprocess line by line and print with prefix."""
    colour = COLOURS.get(label, "")
    prefix = f"{colour}{BOLD}[{label}]{RESET} "

    def _stream(pipe):
        try:
            for raw in iter(pipe.readline, b""):
                line = raw.decode("utf-8", errors="replace").rstrip()
                if line:
                    ts = datetime.now().strftime("%H:%M:%S")
                    print(f"\033[90m{ts}\033[0m {prefix}{line}", flush=True)
        except Exception:
            pass

    t_out = threading.Thread(target=_stream, args=(proc.stdout,), daemon=True)
    t_err = threading.Thread(target=_stream, args=(proc.stderr,), daemon=True)
    t_out.start()
    t_err.start()


# ── Process lifecycle ──────────────────────────────────────────────────────────

_procs = []   # list of (label, Popen)


def start_process(label, cmd, cwd=None):
    col = COLOURS.get(label, "")
    print(f"\n{col}{BOLD}[LAUNCHER] Starting {label}{RESET}")
    print(f"  $ {' '.join(cmd)}")

    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=cwd or os.getcwd(),
        env=os.environ.copy(),
    )
    _procs.append((label, proc))
    stream_output(proc, label)
    return proc


def write_pid_file():
    with open(PID_FILE, "w") as f:
        for label, proc in _procs:
            f.write(f"{label}:{proc.pid}\n")


def stop_all(signum=None, frame=None):
    col = COLOURS["LAUNCHER"]
    print(f"\n{col}{BOLD}[LAUNCHER] Shutting down all processes...{RESET}")
    for label, proc in reversed(_procs):
        if proc.poll() is None:
            print(f"  Stopping {label} (PID {proc.pid})")
            try:
                proc.terminate()
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
            except Exception:
                pass
    if os.path.exists(PID_FILE):
        os.remove(PID_FILE)
    print(f"{col}{BOLD}[LAUNCHER] All stopped.{RESET}")
    sys.exit(0)


def kill_from_pid_file():
    if not os.path.exists(PID_FILE):
        print("[LAUNCHER] No PID file found — nothing to stop.")
        return
    with open(PID_FILE) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            label, pid = line.split(":", 1)
            try:
                os.kill(int(pid), signal.SIGTERM)
                print(f"  Sent SIGTERM to {label} (PID {pid})")
            except ProcessLookupError:
                print(f"  {label} (PID {pid}) already gone")
            except Exception as e:
                print(f"  Error stopping {label}: {e}")
    os.remove(PID_FILE)
    print("[LAUNCHER] Done.")


def wait_for_dashboard(timeout=15):
    """Poll until the dashboard server is accepting connections."""
    import socket
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with socket.create_connection(("localhost", DASHBOARD_PORT), timeout=1):
                return True
        except OSError:
            time.sleep(0.5)
    return False


def check_required_files():
    missing = []
    for f in ["dashboard_server.py", "run_pipeline.py", "rca_agent.py",
              "detection_engine.py", "response_engine.py", "data_pipeline.py"]:
        if not os.path.exists(f):
            missing.append(f)
    return missing


# ── Entry point ────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="SliceShield — one-command launcher"
    )
    parser.add_argument("--stop",            action="store_true",
                        help="Kill all previously launched processes and exit")
    parser.add_argument("--mode",            choices=["demo", "kafka"], default="demo",
                        help="Detection mode (default: demo)")
    parser.add_argument("--train",           action="store_true",
                        help="Run FL training before starting detection")
    parser.add_argument("--no-rca",          action="store_true",
                        help="Skip the RCA forensics agent")
    parser.add_argument("--no-sniffer",      action="store_true",
                        help="Skip the packet sniffer")
    parser.add_argument("--interface",       default="eth0",
                        help="Network interface for packet sniffer (default: eth0)")
    parser.add_argument("--broker",          default="localhost:9093",
                        help="Kafka broker for sniffer (default: localhost:9093)")
    parser.add_argument("--dry-run-sniffer", action="store_true",
                        help="Run packet sniffer in dry-run (no Kafka publish)")
    parser.add_argument("--no-browser",      action="store_true",
                        help="Don't open the browser automatically")
    args = parser.parse_args()

    # ── --stop mode ─────────────────────────────────────────
    if args.stop:
        kill_from_pid_file()
        return

    # ── Pre-flight ───────────────────────────────────────────
    print("""
╔══════════════════════════════════════════════════════════════╗
║          SliceShield — Unified Launcher                      ║
╚══════════════════════════════════════════════════════════════╝""")

    missing = check_required_files()
    if missing:
        print(f"\n[LAUNCHER] ERROR: Missing files: {missing}")
        print("  Make sure you're running from the SliceShield project directory.")
        sys.exit(1)

    os.makedirs("logs", exist_ok=True)
    os.makedirs("models", exist_ok=True)

    # ── Register signal handlers for clean shutdown ──────────
    signal.signal(signal.SIGINT,  stop_all)
    signal.signal(signal.SIGTERM, stop_all)

    # ── Start processes ──────────────────────────────────────
    cmds = build_commands(args)

    for label, cmd in cmds:
        proc = start_process(label, cmd)
        # Stagger starts so each service has time to bind its port
        time.sleep(2 if label == "DASHBOARD" else 1)

    write_pid_file()

    # ── Wait for dashboard + open browser ───────────────────
    col = COLOURS["LAUNCHER"]
    print(f"\n{col}{BOLD}[LAUNCHER] Waiting for dashboard on {DASHBOARD_URL}...{RESET}")
    if wait_for_dashboard(timeout=20):
        print(f"{col}{BOLD}[LAUNCHER] Dashboard ready → {DASHBOARD_URL}{RESET}")
        if not args.no_browser:
            time.sleep(0.5)
            webbrowser.open(DASHBOARD_URL)
    else:
        print(f"{col}[LAUNCHER] Dashboard didn't respond in time — open {DASHBOARD_URL} manually{RESET}")

    # ── Monitor loop — restart crashed processes ─────────────
    print(f"\n{col}{BOLD}[LAUNCHER] All services running. Press Ctrl+C to stop all.{RESET}\n")
    while True:
        time.sleep(5)
        for i, (label, proc) in enumerate(_procs):
            ret = proc.poll()
            if ret is not None:
                print(f"\n{col}{BOLD}[LAUNCHER] {label} exited (code {ret}) — restarting...{RESET}")
                # find original command
                orig_cmd = next(c for l, c in cmds if l == label)
                new_proc = start_process(label, orig_cmd)
                _procs[i] = (label, new_proc)
                write_pid_file()


if __name__ == "__main__":
    main()
