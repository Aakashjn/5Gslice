import os
import sys
import json
import subprocess
from flask import Flask, jsonify, request

# FIX: lazy-import flask_cors with a clear error if missing
try:
    from flask_cors import CORS
except ImportError:
    print("[ERROR] flask-cors not installed. Run: pip install flask-cors")
    sys.exit(1)

app = Flask(__name__)
CORS(app)

LOG_PATH = "logs/response_audit.jsonl"


@app.route("/api/logs")
def get_logs():
    logs = []
    if not os.path.exists(LOG_PATH):
        return jsonify(logs)
    with open(LOG_PATH, "r") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    logs.append(json.loads(line))
                except json.JSONDecodeError:
                    pass
    return jsonify(logs)


@app.route("/api/rca/<int:slice_id>")
def get_rca(slice_id):
    # FIX: wrap os.listdir in try/except so missing cwd files don't crash the server
    try:
        reports = [
            f for f in os.listdir(".")
            if f.startswith(f"RCA_Report_Slice{slice_id}") and f.endswith(".md")
        ]
    except OSError:
        reports = []

    if not reports:
        return jsonify({"report": "No RCA report available yet."})

    latest_report = sorted(reports)[-1]
    try:
        with open(latest_report, "r") as f:
            return jsonify({"report": f.read()})
    except OSError as e:
        return jsonify({"report": f"Error reading report: {e}"}), 500


@app.route("/api/attack", methods=["POST"])
def trigger_attack():
    data = request.get_json(force=True, silent=True) or {}
    slice_id = int(data.get("slice", 1))
    attack_type = str(data.get("attack", "nosql"))

    # FIX 1: validate attack_type against known values to prevent shell injection
    allowed_attacks = {"ddos", "nosql", "lateral", "syn_flood", "port_scan"}
    if attack_type not in allowed_attacks:
        return jsonify({"status": "error", "message": f"Unknown attack type: {attack_type}"}), 400

    # FIX 2: use sys.executable instead of bare 'python' which may not exist on Ubuntu
    subprocess.Popen(
        [sys.executable, "attack_simulation.py", "--slice", str(slice_id), "--attack", attack_type]
    )
    return jsonify({"status": "success", "message": "Attack injected"})


if __name__ == "__main__":
    os.makedirs("logs", exist_ok=True)
    app.run(port=5002, debug=False)
