import os
import time
import json
import queue
import threading
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from collections import deque
from typing import List, Optional, Callable
from datetime import datetime

# ─────────────────────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────────────────────
CFG = {
    "model_path": "models/federated_model.pt",
    "input_dim": 20,
    "hidden_dims": [128, 64, 32],
    "dropout": 0.3,
    "threshold": 0.65,
    "window_size": 5,
    "window_overlap": 2,
    "kafka_topic": "slice-telemetry",
    "kafka_broker": "localhost:9093",
    "malicious_csv": "malicious_data.csv",
    "replay_delay": 0.1,
    "max_queue": 1000,
}

SLICE_NAMES = {0: "eMBB", 1: "URLLC", 2: "mMTC"}

# ─────────────────────────────────────────────────────────────
# MODEL DEFINITION (must match fl_trainer.py)
# ─────────────────────────────────────────────────────────────

class SliceSecurityNet(nn.Module):
    """Mirror of the model defined in fl_trainer.py."""
    def __init__(self, input_dim: int, hidden_dims: List[int],
                 num_classes: int = 2, dropout: float = 0.3):
        super().__init__()
        layers = []
        in_d = input_dim
        for h in hidden_dims:
            layers += [nn.Linear(in_d, h), nn.BatchNorm1d(h),
                       nn.ReLU(), nn.Dropout(dropout)]
            in_d = h
        layers.append(nn.Linear(in_d, num_classes))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)


def load_model(model_path: str) -> Optional[SliceSecurityNet]:
    """Load the trained federated model from disk.
    Returns None if the model file does not exist."""
    if not os.path.exists(model_path):
        print(f"[Detection] WARNING: Model not found at {model_path}")
        print("[Detection] Running without model — all samples will use fallback scoring.")
        return None

    model = SliceSecurityNet(
        input_dim=CFG["input_dim"],
        hidden_dims=CFG["hidden_dims"],
        dropout=CFG["dropout"],
    )
    state_dict = torch.load(model_path, map_location="cpu", weights_only=True)
    model.load_state_dict(state_dict, strict=True)
    model.eval()
    print(f"[Detection] Model loaded from {model_path}")
    return model

# ─────────────────────────────────────────────────────────────
# DETECTION ENGINE
# ─────────────────────────────────────────────────────────────

class DetectionEngine:
    def __init__(self, model: Optional[SliceSecurityNet], alert_callback=None):
        self.model = model
        self.callback = alert_callback
        self.buffers = {sid: deque(maxlen=CFG["window_size"]) for sid in SLICE_NAMES}
        self.alert_queue = queue.Queue(maxsize=CFG["max_queue"])
        self._stats = {"processed": 0, "alerts": 0, "windows": 0}

    def ingest(self, feature_vec, slice_id, raw_text=""):
        """Add a feature vector to the slice buffer and run detection
        when the window is full."""
        self.buffers[slice_id].append(feature_vec)
        self._stats["processed"] += 1
        buf = self.buffers[slice_id]
        if len(buf) >= CFG["window_size"]:
            self._run_detection(list(buf), slice_id, raw_text)

    def _run_detection(self, window, slice_id, raw_text):
        """Run model inference over the window and fire an alert
        if the average attack probability exceeds the threshold."""
        self._stats["windows"] += 1
        t0 = time.perf_counter()

        avg_prob = self._compute_probability(window)

        latency_ms = (time.perf_counter() - t0) * 1000

        if avg_prob >= CFG["threshold"]:
            self._stats["alerts"] += 1
            alert = {
                "timestamp": datetime.now().isoformat(),
                "slice_id": slice_id,
                "slice_name": SLICE_NAMES.get(slice_id, "unknown"),
                "avg_prob": round(avg_prob, 4),
                "latency_ms": round(latency_ms, 2),
                "raw_snippet": raw_text[:200],
            }
            if self.callback:
                self.callback(alert)

        # NOTE: Recovery is handled exclusively by response_engine.py's
        # RecoveryMonitor to avoid conflicting dual-recovery paths.

    def _compute_probability(self, window) -> float:
        """Run the model on each vector in the window and return the
        average attack-class probability.  Falls back to a simple
        heuristic score when no model is loaded."""
        if self.model is None:
            return self._heuristic_score(window)

        probs = []
        with torch.no_grad():
            for vec in window:
                tensor = torch.tensor(vec, dtype=torch.float32).unsqueeze(0)
                logits = self.model(tensor)
                prob = torch.softmax(logits, dim=1)[0, 1].item()  # class 1 = attack
                probs.append(prob)
        return float(np.mean(probs))

    @staticmethod
    def _heuristic_score(window) -> float:
        """Simple rule-based fallback when no trained model is available.
        Uses known attack-indicator feature positions from data_pipeline.py:
            index 1: nrf_discovery
            index 4: nosql_keyword
            index 8: mongo_query
            index 13: injection_depth
        """
        scores = []
        for vec in window:
            v = np.array(vec, dtype=float)
            indicators = 0
            if len(v) > 4 and v[4] > 0:      # nosql_keyword
                indicators += 1
            if len(v) > 8 and v[8] > 0:       # mongo_query
                indicators += 1
            if len(v) > 13 and v[13] > 0.2:   # injection_depth
                indicators += 1
            if len(v) > 1 and v[1] > 0:       # nrf_discovery
                indicators += 0.5
            scores.append(min(indicators / 3.0, 1.0))
        return float(np.mean(scores))

    def stats(self):
        return self._stats.copy()

# ─────────────────────────────────────────────────────────────
# KAFKA CONSUMER
# ─────────────────────────────────────────────────────────────

def start_kafka_consumer(engine):
    from kafka import KafkaConsumer
    consumer = KafkaConsumer(
        CFG["kafka_topic"],
        bootstrap_servers=CFG["kafka_broker"],
        value_deserializer=lambda v: json.loads(v.decode("utf-8")),
        auto_offset_reset="earliest",
    )
    print(f"[Detection] Kafka consumer connected → {CFG['kafka_broker']}")
    for msg in consumer:
        data = msg.value
        slice_id = int(data.get("slice_id", 0))
        features = data.get("features", None)
        raw = data.get("payload_snippet", data.get("raw", ""))

        if features is not None:
            feature_vec = np.array(features, dtype=np.float32)
        else:
            feature_vec = np.zeros(CFG["input_dim"], dtype=np.float32)

        engine.ingest(feature_vec, slice_id, raw)


def run(mode="demo", alert_callback=None):
    """Initialise and return a DetectionEngine.
    In 'kafka' mode the consumer loop runs in the foreground."""
    model = load_model(CFG["model_path"])
    engine = DetectionEngine(model, alert_callback)

    if mode == "kafka":
        start_kafka_consumer(engine)

    return engine
