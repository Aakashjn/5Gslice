import os
import time
import json
import requests
from datetime import datetime

LOG_FILE = "logs/response_audit.jsonl"
GROQ_TIMEOUT = 30   # seconds — FIX: was unbounded, could hang forever


def generate_rca(event_data):
    api_key = os.environ.get("GROQ_API_KEY", "").strip()

    # FIX: return False so the caller can decide whether to retry/skip
    if not api_key:
        print("[ERROR] GROQ_API_KEY is not set. Export it before starting rca_agent.py:")
        print("        export GROQ_API_KEY='your_key_here'")
        return False

    slice_id = event_data.get("slice_id")
    print(f"\n[RCA Agent] Analyzing attack on Slice {slice_id} via Groq (Llama 3)...")

    prompt = f"""You are an expert 5G Core Cybersecurity Analyst.
Review the following automated slice isolation log and generate a concise Root Cause Analysis (RCA) report in Markdown.
Focus on the attack type, probability, and the IoCs (Indicators of Compromise).

LOG DATA:
{json.dumps(event_data, indent=2)}
"""

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": "llama-3.1-8b-instant",
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.2,
    }

    try:
        # FIX: added timeout= so the call can't hang forever
        response = requests.post(
            "https://api.groq.com/openai/v1/chat/completions",
            headers=headers,
            json=payload,
            timeout=GROQ_TIMEOUT,
        )
        response.raise_for_status()
        report = response.json()["choices"][0]["message"]["content"]

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        out_file = f"RCA_Report_Slice{slice_id}_{timestamp}.md"

        with open(out_file, "w") as f:
            f.write(report)

        print(f"[SUCCESS] RCA Report saved to: {out_file}\n")
        print(report)
        return True

    except requests.exceptions.Timeout:
        print(f"\n[ERROR] Groq API timed out after {GROQ_TIMEOUT}s. Will retry on next event.\n")
    except requests.exceptions.RequestException as e:
        print(f"\n[ERROR] Failed to contact Groq API: {e}\n")
    return False


def watch_logs():
    # FIX: guard against missing GROQ_API_KEY up-front with a clear warning
    # (but don't exit — the key might be set later or events could still be logged)
    if not os.environ.get("GROQ_API_KEY", "").strip():
        print("[WARNING] GROQ_API_KEY is not set. RCA reports will be skipped until it is.")
        print("          Set it with: export GROQ_API_KEY='your_key_here'\n")

    print(f"[*] RCA Agent Active. Watching {LOG_FILE} for new isolations...")
    os.makedirs("logs", exist_ok=True)

    # Create the log file if it doesn't exist yet
    if not os.path.exists(LOG_FILE):
        open(LOG_FILE, "a").close()

    with open(LOG_FILE, "r") as f:
        # Seek to end so we only catch NEW events, not replaying history
        f.seek(0, 2)
        while True:
            line = f.readline()
            if not line:
                time.sleep(1)
                continue

            line = line.strip()
            if not line:
                continue

            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue

            # Only trigger on actual isolations, not readmissions
            if event.get("event") == "slice_isolated":
                print("\n" + "=" * 60)
                print("[!] New Slice Isolation Detected! Triggering Analysis...")
                generate_rca(event)   # FIX: no longer exits loop on missing key
                print("=" * 60)


if __name__ == "__main__":
    watch_logs()
