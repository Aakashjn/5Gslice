"""
response_engine.py
==================
Layer 4 of the full pipeline.
Receives alerts from DetectionEngine and triggers:
  1. Immediate SDN flow rule via SSH to VM (Mininet/OVS)
  2. Recovery monitoring
  3. Full audit log
"""

import os
import time
import json
import subprocess
import logging
from datetime import datetime
from typing import Dict, List, Optional
from collections import defaultdict

# ─────────────────────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────────────────────
CFG = {
    "ryu_enabled":         True,
    "max_isolations_min":  3,       # circuit breaker — max isolations per minute
    "clean_windows_req":   3,       # windows below threshold before re-admission
    "clean_threshold":     0.30,    # probability below this = clean window
    "log_dir":             "logs",
    "audit_log":           "logs/response_audit.jsonl",

    # FIX: SSH config moved into CFG so it's easy to change without editing code
    "ssh_user":            "aakash",
    "ssh_host":            "127.0.0.1",
    "ssh_port":            2222,
    "ssh_timeout":         10,      # seconds before SSH attempt is abandoned
}

SLICE_NAMES = {0: "eMBB", 1: "URLLC", 2: "mMTC"}

# Per-slice SDN config: Slice 0 = Port 1, Slice 1 = Port 2, Slice 2 = Port 3
SLICE_SDN_CONFIG = {
    0: {"port": 1, "priority": 200},
    1: {"port": 2, "priority": 210},
    2: {"port": 3, "priority": 220},
}

RESPONSE_PLAYBOOK = {
    "nosql_injection": {
        "immediate":   ["Block source IP at NRF ingress",
                        "Rate-limit /nnrf-disc/ to 10 req/s",
                        "Enable MongoDB query validation"],
        "containment": ["Quarantine slice VLAN", "Freeze NRF VNF instance"],
        "recovery":    ["Re-validate all NF registrations", "Restore MongoDB ACLs"],
    },
    "ddos": {
        "immediate":   ["Rate-limit ingress to 1,000 pps",
                        "Blackhole top-N source IPs"],
        "containment": ["Isolate slice VLAN", "Redirect via DDoS proxy"],
        "recovery":    ["Monitor for 3 clean windows"],
    },
    "lateral_movement": {
        "immediate":   ["CRITICAL: Block all inter-slice egress",
                        "Alert neighboring slices"],
        "containment": ["Hard-isolate compromised slice"],
        "recovery":    ["Full forensic analysis required"],
    },
    "default": {
        "immediate":   ["Block suspicious source",
                        "Rate-limit affected endpoint"],
        "containment": ["Isolate slice"],
        "recovery":    ["Monitor for clean windows"],
    },
}

# ─────────────────────────────────────────────────────────────
# CIRCUIT BREAKER & AUDIT LOGGER
# ─────────────────────────────────────────────────────────────

class CircuitBreaker:
    def __init__(self, max_per_min: int):
        self.max      = max_per_min
        self.count    = 0
        self.reset_at = time.time() + 60

    def allow(self) -> bool:
        if time.time() > self.reset_at:
            self.count    = 0
            self.reset_at = time.time() + 60
        if self.count >= self.max:
            return False
        self.count += 1
        return True


def setup_audit_log():
    os.makedirs(CFG["log_dir"], exist_ok=True)


def write_audit(event: dict):
    with open(CFG["audit_log"], "a") as f:
        f.write(json.dumps(event) + "\n")

# ─────────────────────────────────────────────────────────────
# DISTRIBUTED SDN CONTROLLER (Host → VM via SSH)
# ─────────────────────────────────────────────────────────────

class DistributedSDNController:
    def __init__(self, enabled: bool = True):
        self.enabled = enabled

    def _ssh(self, ovs_cmd: str) -> bool:
        """Run an ovs-ofctl command on the remote VM via SSH.
        Returns True on success, False on failure.
        FIX: all SSH calls go through here with a timeout and proper error handling."""
        if not self.enabled:
            print(f"    [SDN] (disabled) would run: {ovs_cmd}")
            return True

        ssh_target = (
            f"{CFG['ssh_user']}@{CFG['ssh_host']}"
        )
        cmd = [
            "ssh",
            "-p", str(CFG["ssh_port"]),
            "-o", "StrictHostKeyChecking=no",
            "-o", f"ConnectTimeout={CFG['ssh_timeout']}",
            ssh_target,
            f"sudo {ovs_cmd}",
        ]

        try:
            subprocess.run(
                cmd,
                check=True,                     # raises on non-zero exit
                capture_output=True,            # suppress noise
                timeout=CFG["ssh_timeout"] + 5, # hard wall-clock timeout
            )
            return True
        except subprocess.TimeoutExpired:
            print(f"    [SDN] SSH timed out running: {ovs_cmd}")
        except subprocess.CalledProcessError as e:
            stderr = e.stderr.decode(errors="replace").strip()
            print(f"    [SDN] SSH command failed (exit {e.returncode}): {stderr}")
        except FileNotFoundError:
            print("    [SDN] 'ssh' not found on this machine — SDN isolation skipped.")
        return False

    def isolate_slice(self, slice_id: int) -> dict:
        cfg  = SLICE_SDN_CONFIG.get(slice_id, {})
        port = cfg.get("port", 1)
        t0   = time.perf_counter()

        ovs_cmd = f"ovs-ofctl add-flow s1 priority=200,in_port={port},actions=drop"
        ok = self._ssh(ovs_cmd)
        latency_ms = (time.perf_counter() - t0) * 1000

        if ok:
            print(f"    [SDN] Slice {slice_id} isolated ({latency_ms:.1f} ms)")
            return {"status": "isolated", "latency_ms": round(latency_ms, 2)}
        else:
            return {"status": "failed",   "latency_ms": round(latency_ms, 2)}

    def restore_slice(self, slice_id: int) -> dict:
        cfg  = SLICE_SDN_CONFIG.get(slice_id, {})
        port = cfg.get("port", 1)
        t0   = time.perf_counter()

        # FIX: restore_slice now also uses _ssh() so failures are caught and reported
        ovs_cmd = f"ovs-ofctl del-flows s1 in_port={port}"
        ok = self._ssh(ovs_cmd)
        latency_ms = (time.perf_counter() - t0) * 1000

        if ok:
            print(f"    [SDN] Slice {slice_id} restored ({latency_ms:.1f} ms)")
            return {"status": "restored", "latency_ms": round(latency_ms, 2)}
        else:
            return {"status": "failed",   "latency_ms": round(latency_ms, 2)}

# ─────────────────────────────────────────────────────────────
# RECOVERY MONITOR
# ─────────────────────────────────────────────────────────────

class RecoveryMonitor:
    def __init__(self, sdn: DistributedSDNController, audit_fn):
        self.sdn          = sdn
        self.audit_fn     = audit_fn
        self.isolated     = {}
        self.clean_counts = defaultdict(int)
        self._stats       = {"readmissions": 0}

    def record_window(self, slice_id: int, avg_prob: float):
        if slice_id not in self.isolated:
            return
        if avg_prob < CFG["clean_threshold"]:
            self.clean_counts[slice_id] += 1
            if self.clean_counts[slice_id] >= CFG["clean_windows_req"]:
                self._readmit(slice_id)
        else:
            self.clean_counts[slice_id] = 0

    def _readmit(self, slice_id: int):
        sdn_result = self.sdn.restore_slice(slice_id)
        self.isolated.pop(slice_id, None)
        self.clean_counts[slice_id] = 0
        self._stats["readmissions"] += 1
        event = {
            "event":     "slice_readmitted",
            "timestamp": datetime.now().isoformat(),
            "slice_id":  slice_id,
            "sdn":       sdn_result,
        }
        self.audit_fn(event)
        print(f"  [Recovery] Slice {slice_id} readmitted after {CFG['clean_windows_req']} clean windows.")

    def mark_isolated(self, slice_id: int):
        self.isolated[slice_id]     = time.time()
        self.clean_counts[slice_id] = 0

    def stats(self) -> dict:
        return self._stats.copy()

# ─────────────────────────────────────────────────────────────
# RESPONSE ENGINE
# ─────────────────────────────────────────────────────────────

class ResponseEngine:
    def __init__(self):
        setup_audit_log()
        self.sdn      = DistributedSDNController(CFG["ryu_enabled"])
        self.breaker  = CircuitBreaker(CFG["max_isolations_min"])
        self.recovery = RecoveryMonitor(self.sdn, write_audit)
        self._stats   = {"alerts_received": 0, "isolations": 0, "readmissions": 0}

    def handle_alert(self, alert: dict):
        self._stats["alerts_received"] += 1
        slice_id = alert["slice_id"]

        # Let the recovery monitor check if this window clears the slice
        self.recovery.record_window(slice_id, alert["avg_prob"])

        if self.breaker.allow():
            t_isolate  = time.perf_counter()
            sdn_result = self.sdn.isolate_slice(slice_id)
            isolate_ms = (time.perf_counter() - t_isolate) * 1000

            self.recovery.mark_isolated(slice_id)
            self._stats["isolations"] += 1

            write_audit({
                "event":       "slice_isolated",
                "timestamp":   alert["timestamp"],
                "slice_id":    slice_id,
                "attack_type": self._classify_attack(alert.get("iocs", [])),
                "avg_prob":    alert.get("avg_prob", 0),
                "total_ms":    round(alert["latency_ms"] + isolate_ms, 2),
                "sdn":         sdn_result,
            })
        else:
            print(f"  [CircuitBreaker] Too many isolations — skipping Slice {slice_id}")

    def _classify_attack(self, iocs: List[str]) -> str:
        ioc_text = " ".join(iocs).lower()
        if "nosql"    in ioc_text: return "nosql_injection"
        if "ddos"     in ioc_text: return "ddos"
        if "lateral"  in ioc_text: return "lateral_movement"
        return "default"

    def stats(self) -> dict:
        # FIX: merge readmissions from RecoveryMonitor into top-level stats
        s = self._stats.copy()
        s["readmissions"] = self.recovery.stats()["readmissions"]
        return s


def run() -> ResponseEngine:
    return ResponseEngine()
